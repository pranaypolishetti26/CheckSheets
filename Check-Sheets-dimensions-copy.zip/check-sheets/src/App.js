// App.js
import React, { useState, useEffect } from 'react';
import { getUsers } from './components/apiService'; // Import the function from apiService.js
import UserSelection from './components/UserSelection';
import Header from './components/Header'; //  Header is the next component to be shown

const App = () => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const usersData = await getUsers();
        setUsers(usersData);
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  const handleSelectUser = (user) => {
    setSelectedUser(user);
  };

  return (
    <div>
      {!selectedUser ? (
        <UserSelection users={users} onSelectUser={handleSelectUser} />
      ) : (
        <Header selectedUser={selectedUser} />
      )}
    </div>
  );
};

export default App;
